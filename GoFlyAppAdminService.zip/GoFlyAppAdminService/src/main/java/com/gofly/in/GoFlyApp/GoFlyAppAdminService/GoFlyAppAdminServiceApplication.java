package com.gofly.in.GoFlyApp.GoFlyAppAdminService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoFlyAppAdminServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoFlyAppAdminServiceApplication.class, args);
	}

}
