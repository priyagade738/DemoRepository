package com.gofly.in.GoFlyApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoFlyAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoFlyAppApplication.class, args);
	}

}
