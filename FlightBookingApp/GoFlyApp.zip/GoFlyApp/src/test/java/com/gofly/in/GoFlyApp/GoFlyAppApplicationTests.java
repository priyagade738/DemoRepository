package com.gofly.in.GoFlyApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoFlyAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
